#ifndef STOCK_H
#define STOCK_H

#include <vector>
#include "investment.h"

class Stock : public investment
{
public:
  Stock();
  ~Stock();
};


#endif
